/**
 * Reply enum used to define the types of replies sent from Control to View
 * @author Kevin McAllister (40031326) - Iteration 1
 */
package control;

public enum ReplyType {

    UPDATE, END
}
