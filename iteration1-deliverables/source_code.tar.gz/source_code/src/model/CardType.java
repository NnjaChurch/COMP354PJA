/**
 * CardType enum used to determine what type each card is (Blue, Red, Assassin, Bystander)
 * @author Kevin McAllister (40031326) - Iteration 1
 */
package model;

public enum CardType {
    BLUE, RED, BLACK, YELLOW
}
